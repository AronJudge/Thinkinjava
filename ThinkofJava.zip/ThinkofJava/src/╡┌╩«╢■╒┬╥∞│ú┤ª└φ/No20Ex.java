package 第十二章异常处理;

public class No20Ex {
    void f() throws VeryImportantException {
        throw new VeryImportantException();
    }
    void dispose() throws HoHumException {
        throw new HoHumException();
    }
    public static void main(String[] args) {
        try {
            No20Ex lmf = new No20Ex();
            try {
                lmf.f();
            } catch(Exception e) {
                System.out.println(e);
            } finally {
                lmf.dispose();
            }

        } catch(Exception e) {
            System.out.println(e);
        }
    }
}