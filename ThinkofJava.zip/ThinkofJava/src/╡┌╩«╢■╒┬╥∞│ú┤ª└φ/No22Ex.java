package 第十二章异常处理;
/* Create a class called FailingConstructor with a constructor that might fail
 * partway through the construction process and throw an exception. In main(),
 * write code that properly guards against this failure.
 */

public class No22Ex {
    Integer[] ia = new Integer[2];
    String s;
    No22Ex(String s) throws Exception {
        ia[0] = 0;
        ia[1] = 1;
        ia[2] = 2;
        this.s = s;
    }
    public static void main(String[] args) {
        try {
            No22Ex fc = new No22Ex("hi");
        } catch(Exception e) {
            System.err.println("Caught Exception in main()");
            e.printStackTrace(System.err);
        } finally {

        }
    }
}
