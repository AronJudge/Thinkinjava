package 第十二章异常处理;
// Modify Exercise 3 to convert the exception to a Runtime Exception.

public class No27Ex {
    private static int[] ia = new int[2];
    public static void main(String[] args) {
        try {
            ia[2] = 3;
        } catch(ArrayIndexOutOfBoundsException e) { // convert to RuntimeException:
            throw new RuntimeException(e);
        }
    }
}