package 第十二章异常处理;

/* Create two exception classes, each of which performs its own logging
 * automtically. Demonstrate that these work.
 */
import java.util.logging.*;
import java.io.*;

class Oops1 extends Exception {
    private static Logger logger = Logger.getLogger("LoggingException");//与错误相关的包名或者类名字
    public Oops1() {
        StringWriter trace = new StringWriter();
        printStackTrace(new PrintWriter(trace));//获取抛出处的栈轨迹，接受Java。io。PrintWriter对象作为参数从而产生字符串
        logger.severe(trace.toString());//severe 直接调用与日志消息的级别相关联的方法
    }
}

class Oops2 extends Exception {
    private static Logger logger = Logger.getLogger("LoggingException");
    public Oops2() {
        StringWriter trace = new StringWriter();
        printStackTrace(new PrintWriter(trace));
        logger.severe(trace.toString());
    }
}

public class No6Ex {
    static void f() throws Oops1 {
        throw new Oops1();
    }
    static void g() throws Oops2 {
        throw new Oops2();
    }
    public static void main(String[] args) {
        try {
            f();
        } catch(Exception Oops1) {}
        try {
            g();
        } catch(Exception Oops2) {}
    }
}
