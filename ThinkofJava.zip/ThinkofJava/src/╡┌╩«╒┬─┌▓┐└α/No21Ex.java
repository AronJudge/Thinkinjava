package 第十章内部类;

interface In21 {
    String f();
    String g();
    class Nested {
        static void testIn(In21 i) {
            System.out.println(i.f() + i.g());
        }
    }
}

public class No21Ex implements In21 {
    public String f() { return "hello "; }
    public String g() { return "friend"; }
    public static void main(String[] args) {
        No21Ex x = new No21Ex();
        In21.Nested.testIn(x);
    }
}