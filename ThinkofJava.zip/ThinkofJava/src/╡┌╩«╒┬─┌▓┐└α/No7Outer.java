package 第十章内部类;

class No7Outer {
    private int oi = 1;
    private void hi() { System.out.println("Outer hi"); }
    class Inner {
        void modifyOuter() {
            oi *= 2;
            hi();
        }
    }
    public void showOi() { System.out.println(oi); }
    void testInner() {
        Inner in = new Inner();
        in.modifyOuter();
    }
    public static void main(String[] args) {
        No7Outer out = new No7Outer();
        out.showOi();
        out.testInner();
        out.showOi();
    }
}