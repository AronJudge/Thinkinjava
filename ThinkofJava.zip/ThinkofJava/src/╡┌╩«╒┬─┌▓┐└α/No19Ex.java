package 第十章内部类;

/* Create a class containing an inner class that itself contains an inner
 * class. Repeat this using nested classes. Note the names of the .class files
 * produced by the compiler.
 */

public class No19Ex {
    No19Ex() { System.out.println("Ex19()"); }
    private class Ex19Inner {
        Ex19Inner() { System.out.println("Ex19Inner()"); }
        private class Ex19InnerInner {
            Ex19InnerInner() {
                System.out.println("Ex19InnerInner()");
            }
        }
    }
    private static class Ex19Nested {
        Ex19Nested() { System.out.println("Ex19Nested()"); }
        private static class Ex19NestedNested {
            Ex19NestedNested() {
                System.out.println("Ex19NestedNested()");
            }
        }
    }
    public static void main(String[] args) {
        Ex19Nested en = new Ex19Nested();
        Ex19Nested.Ex19NestedNested enn = new Ex19Nested.Ex19NestedNested();
        No19Ex e19 = new No19Ex();
        No19Ex.Ex19Inner ei = e19.new Ex19Inner();
        No19Ex.Ex19Inner.Ex19InnerInner eii = ei.new Ex19InnerInner();
    }
}

/* compiler produces:
 * Ex19$Ex19Inner$Ex19InnerInner.class
 * Ex19$Ex19Inner.class
 * Ex19$Ex19Nested$Ex19NestedNested.class
 * Ex19$Ex19Nested.class
 * Ex19.class
 */