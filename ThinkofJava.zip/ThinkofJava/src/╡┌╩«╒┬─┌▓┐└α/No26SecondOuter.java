package 第十章内部类;

/* Create a class with an inner class that has a non-default constructor
 * (one that takes arguments). Create a second class with an inner
 * class that inherits from the first inner class.
 */

class FirstOuter {
    public class FirstInner {
        FirstInner(String s) {
            System.out.println("FirstOuter.FirstInner() " + s );
        }
    }
}

public class No26SecondOuter {
    public class SecondInner extends FirstOuter.FirstInner {
        SecondInner(FirstOuter x) {
            x.super("hello");
            System.out.println("SecondOuter.SecondInner()");
        }
    }
    public static void main(String[] args) {
        FirstOuter fo = new FirstOuter();
        //FirstOuter.FirstInner fs = new FirstOuter.FirstInner("s");
        No26SecondOuter so = new No26SecondOuter();
        SecondInner si = so.new SecondInner(fo);
    }
}