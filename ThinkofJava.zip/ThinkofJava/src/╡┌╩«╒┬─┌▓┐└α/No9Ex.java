package 第十章内部类;

interface Ex9Interface {
    void say(String s);
}

public class No9Ex {
    Ex9Interface f() {
        class Inner implements Ex9Interface {
            public void say(String s) {
                System.out.println(s);
            }
        }
        return new Inner();
    }
    public static void main(String[] args) {
        No9Ex x = new No9Ex();
        x.f().say("hi");
    }
}