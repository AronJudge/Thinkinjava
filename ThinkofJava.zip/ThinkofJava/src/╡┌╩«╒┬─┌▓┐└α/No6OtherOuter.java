package 第十章内部类;

/* Create a class with an inner class. In a separate class, make an
 * instance of the inner class.
 */

class Outer {
    class Inner {
        Inner() { System.out.println("Outer.Inner()"); }
    }
}


public class No6OtherOuter {
    public static void main(String[] args) {
        // must first create outer class object:
        Outer o = new Outer();
        // then create inner class object:
        Outer.Inner oi = o.new Inner();
    }
}