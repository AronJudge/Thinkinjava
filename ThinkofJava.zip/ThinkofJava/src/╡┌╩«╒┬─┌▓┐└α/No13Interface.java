package 第十章内部类;

interface Ex13Interface {
    String say(String s);
}

public class No13Interface {
    Ex13Interface f() {
        return new Ex13Interface() {
            public String say(String s) { return s; }
        };
    }
    public static void main(String[] args) {
        No13Interface o = new No13Interface();
        System.out.println(o.f().say("Hi"));
    }
}