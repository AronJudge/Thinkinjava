package 第十章内部类;

public class No1Outer {
    class Inner {
        Inner() { System.out.println("Inner()"); }
    }
    No1Outer() { System.out.println("Outer1()"); }
    // make an Inner from within a non-static method of outer class:
    Inner makeInner() {
        return new Inner();
    }
    public static void main(String[] args) {
        No1Outer o = new No1Outer();
        Inner i = o.makeInner();
    }
}