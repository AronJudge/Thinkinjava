package 第十章内部类;

public class No3Innter {
    private String s;
    class Inner3 {
        Inner3() { System.out.println("Inner()"); }
        public String toString() { return s; }
    }
    No3Innter(String s) {
        System.out.println("Outer1()");
        this.s = s;
    }
    Inner3 makeInner3() {
        return new Inner3();
    }
    public static void main(String[] args) {
        No3Innter o = new No3Innter("Hi is risen!");
        Inner3 i = o.makeInner3();
        System.out.println(i.toString());
    }
}
