package 第十章内部类;


class One {
    private String s;
    One(String s) { this.s = s; }
    public String showS() { return s; }
}

public class No15Ex {
    public One makeOne(String s) {
        return new One(s) { };
    }
    public static void main(String[] args) {
        No15Ex x = new No15Ex();
        System.out.println(x.makeOne("hi").showS());
    }
}