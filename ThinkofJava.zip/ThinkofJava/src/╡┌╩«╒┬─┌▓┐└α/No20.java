package 第十章内部类;

interface In {
    class Nested {
        Nested() { System.out.println("Nested()"); }
        public void hi() { System.out.println("hi"); }
    }
}

public class No20 implements In {
    public static void main(String[] args) {
        In.Nested in = new In.Nested();
        in.hi();
    }
}