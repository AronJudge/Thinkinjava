package 第十一章持有对象;
/* Fill a PriorityQueue (using offer()) with Double values created using
 * java.util.Random, then remove the elements using poll() and display them.
 */
import java.util.*;

class Simple extends Object {}

public class No29Ex {
    public static void main(String[] args) {
        PriorityQueue<Simple> s = new PriorityQueue<Simple>();
        // OK to add one Simple:
        s.offer(new Simple());
        // but no more allowed; get runtime exception:
        // Simple cannot be cast to Comparable:
        s.offer(new Simple());
    }
}

