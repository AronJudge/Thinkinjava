package 第六章访问权限控制;

public class 练习4 {
}
