package 第三章操作符;
class VelocityCalculator1{
    static float velocity(float d,float t)
    {
        if(t == 0) return 0f;
        else  return d/t;
    }
}

public class VelocityCalculator {

    public static void main(String[] args) {
        float d = 902.3f;
        float t = 100.4f;
        System.out.println("Distance =" +d);
        System.out.println("time =" + t);
        float a = VelocityCalculator1.velocity(d,t);
        System.out.println("Velocity =" + a);

    }
}
