package 第三章操作符;

class Doog{
    String name;
    String say;
    void setName(String n){
        name = n;
    }
    void setSay(String s){
        say = s;
    }
    void showName(){
        System.out.println(name);
    }
    void showSay(){
        System.out.println(say);
    }
}
public class dog {
    public static void main(String[] args) {
        Doog dog1 = new Doog();
        Doog dog2 = new Doog();
        dog1.setName("spot");
        dog1.setSay("Ruff");
        dog2.setName("Scrufy");
        dog2.setSay("Ruff");
        dog1.showName();
        dog1.showSay();
        dog2.showName();
        dog2.showSay();


    }
}

