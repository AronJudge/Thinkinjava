package 第三章操作符;

import java.util.Random;

public class simulates_coin_flipping {
    public static void main(String[] args) {
        Random rond = new Random();
        int coin = rond.nextInt();
        if (coin % 2==0) System.out.println("heads");
        else System.out.println("tails");
    }
}
