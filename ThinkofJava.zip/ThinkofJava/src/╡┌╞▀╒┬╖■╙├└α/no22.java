package 第七章服用类;

class SmallBrain {}

final class Dinosaur {
    SmallBrain x = new SmallBrain();
}

// class Further extends Dinosaur {} // error: cannot inherit from final Dinosaur

public class no22 {
    public static void main(String[] args) {
        Dinosaur d = new Dinosaur();
    }
}