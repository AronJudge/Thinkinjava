package 第七章服用类;

class A7 {
    A7(char c, int i) {
        System.out.println("A(char, int)");}
}

class B7 extends A7 {
    B7(String s, float f){
        super(' ', 0);
        System.out.println("B(String, float)");
    }
}

class no7 extends A7 {
    private char c;
    private int i;
    no7(char a, int j) {
        super(a, j);
        c = a;
        i = j;
    }
    B7 b = new B7("hi", 1f); // will then construct another A and then a B
    public static void main(String[] args) {
        no7 c = new no7('b', 2); // will construct an A first
    }
}