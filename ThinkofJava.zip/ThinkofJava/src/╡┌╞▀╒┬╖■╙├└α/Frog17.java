package 第七章服用类;

class Amphibian1 {
    protected void swim() {
        System.out.println("Amphibian1 swim");
    }
    protected void speak() {
        System.out.println("Amphibian1 speak");
    }
    void eat() {
        System.out.println("Amphibian1 eat");
    }
    static void grow(Amphibian1 a) {
        System.out.println("Amphibian1 grow");
        a.eat();
    }
}

public class Frog17 extends Amphibian1 {
    @Override protected void swim() {
        System.out.println("Frog swim");
    }
    @Override protected void speak() {
        System.out.println("Frog speak");
    }
    @Override void eat() {
        System.out.println("Frog eat");
    }
    static void grow(Amphibian1 a) {
        System.out.println("Frog grow");
        a.eat();
    }
    public static void main(String[] args) {
        Frog17 f = new Frog17();
        // call overridden base-class methods:
        f.swim();
        f.speak();
        f.eat();
        // upcast Frog17 to Amphibian argument:
        f.grow(f);
        // upcast Frog17 to Amphibian and call Amphibian method:
        Amphibian1.grow(f);
    }
}