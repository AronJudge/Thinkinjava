package 第七章服用类;

class ThreeWay {
    void number(byte b) {
        System.out.println(b); }
    void number(short s) {
        System.out.println(s); }
    void number(int i) {
        System.out.println(i); }
}

class no13 extends ThreeWay {
    void number(float f) {
        System.out.println(f); }
    public static void main(String[] args) {
        no13 ov = new no13();
        ov.number((byte)0);
        ov.number((short)1);
        ov.number(2);
        ov.number(3.0f);
    }
}
