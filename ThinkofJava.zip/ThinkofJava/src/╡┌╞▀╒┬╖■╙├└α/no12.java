package 第七章服用类;

class Componenta {
    Componenta() {
        System.out.println("Componenta()"); }
    void dispose() {
        System.out.println("Componenta.dispose()"); }
}

class Componentb {
    Componentb() {
        System.out.println("Componentb()"); }
    void dispose() {
        System.out.println("Componentb.dispose()"); }
}

class Componentc {
    Componentc() {
        System.out.println("Componentc()"); }
    void dispose() {
        System.out.println("Componentc.dispose()"); }
}

class Root2 {
    Componenta c1root;
    Componentb c2root;
    Componentc c3root;
    Root2() {
        System.out.println("Root()");
        c1root = new Componenta();
        c2root = new Componentb();
        c3root = new Componentc();
    }
    void dispose() {
        c3root.dispose();
        c2root.dispose();
        c1root.dispose();
        System.out.println("Root2.dispose()");
    }
}

class no12 extends Root2 {
    Componenta c1no12;
    Componentb c2no12;
    Componentc c3no12;
    no12() {
        super();
        System.out.println("no12()");
        c1no12 = new Componenta();
        c2no12 = new Componentb();
        c3no12 = new Componentc();
    }
    void dispose() { // 反向清楚
        c3no12.dispose();
        c2no12.dispose();
        c1no12.dispose();
        super.dispose();
        System.out.println("no12.dispose()");
    }
    public static void main(String[] args) {
        no12 s = new no12();
        try {
            // Code and exception handling...
        } finally {
            s.dispose();
        }
    }
}