package 第七章服用类;

class A23 {
    static int j = printInit("A23.j initialized");
    static int printInit(String s) {
        System.out.println(s);
        return 1;
    }
    A23() {
        System.out.println("A23() constructor"); }
}

class B23 extends A23 {
    static int k = A23.printInit("B23.k initialized");
    B23() {
        System.out.println("B23() constructor"); }
}

class C23 {
    static int n = printInitC("C23.n initialized");
    static A23 a = new A23();
    C23() {
        System.out.println("C23() constructor"); }
    static int printInitC(String s) {
        System.out.println(s);
        return 1;
    }
}

class D23 {
    D23() {
        System.out.println("D23() constructor"); }
}

public class no23 extends B23 {
    static int i = A23.printInit("no23.i initialized");
    no23() {
        System.out.println("no23() constructor"); }
    public static void main(String[] args) {
        // accessing static main causes loading (and initialization)
        // of A, B, & no23
        System.out.println("hi");
        // call constructors from loaded classes:
        no23 lc = new no23();
        // call to static field loads & initializes C:
        System.out.println(C23.a);
        // call to constructor loads D:
        D23 d = new D23();
    }
}