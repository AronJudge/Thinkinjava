package 第七章服用类;

class A { A(){
    System.out.println("A()");} }

class B extends A { B(){
    System.out.println("B()");} }

class C extends B { C(){
    System.out.println("C()");} }

class D extends C {
    D() {
        System.out.println("D()"); }
    public static D makeD() { return new D(); }
    public static void main(String[] args) {
        D d = new D();
        D d2 = makeD();
    }
}

public class no4 extends D {
    no4() {
        System.out.println("no4"); }
    public static void main(String[] args) {
        no4 e = new no4();
        // test D:
        D.main(args);
    }
}
