package 第七章服用类;

class Art {
    Art() {
        System.out.println("Art constructor"); }
}

class Drawing extends Art {
    Drawing() {
        System.out.println("Drawing constructor"); }
}

public class no3 extends Drawing {
    public static void main(String[] args) {
        no3 x = new no3();
    }
}