package 第七章服用类;

class A8 {
    A8(char c, int i) {
        System.out.println("A(char, int)");}
}

class no8 extends A8 {
    private char c;
    private int i;
    no8() {
        super('z', 3);
        System.out.println("no8()");
    }
    no8(char a, int j) {
        super(a, j);
        c = a;
        i = j;
        System.out.println("no8(char,int)");
    }
    public static void main(String[] args) {
        no8 ex1 = new no8();
        no8 ex2 = new no8('b', 2);
    }
}