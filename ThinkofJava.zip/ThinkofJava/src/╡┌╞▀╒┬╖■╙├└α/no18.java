package 第七章服用类;

import java.util.Random;

class Test {
    Test() {
        System.out.println("Test()"); }
}

public class no18 {
    private String name;

    public no18(String s) {
        name = s;
    }

    static final Test sft = new Test(); // constant reference address  // 只执行了一次 初始化 后面 再也不变 所以输出 三个
    private final Test ft = new Test();
    static final String SFS = "static final"; // class constant
    private final String fs = "final";
    private static Random rand = new Random();
    static final int SFI = rand.nextInt(); // class constant
    private final int fi = rand.nextInt();

    public String toString() {
        return (name + ": " + sft + ", " + ft + ", " + SFS + ", " + fs + ", " + SFI + ", " + fi);
    }

    public static void main(String[] args) {
        no18 d1 = new no18("d1");
        no18 d2 = new no18("d2");
        no18 d3 = new no18("d3");
        System.out.println(d1);
        System.out.println(d2);
        System.out.println(d3);
    }
}

