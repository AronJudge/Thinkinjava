package 第七章服用类;

class A1 {
    A1(){
    System.out.println("A1()");}
}

class B1 extends A1 {
    B1(){
    System.out.println("B1()");}
}

class no5 extends A1 {
    B1 b1 = new B1(); // will then construct another A and then a B
    public static void main(String[] args) {
        no5 n5 = new no5(); // will construct an A first
        System.out.println("=========");
    }
}