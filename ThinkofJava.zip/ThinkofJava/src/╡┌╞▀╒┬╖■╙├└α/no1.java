package 第七章服用类;

class Engine1{
    private String s;
    Engine1() {
        System.out.println("Engine()");
        s = "Constructed";
    }
    public String toString() { return s; }
}

public class no1 {
    private String fuselage, wings, tail;
    private Engine e; //e = null;
    public no1() {
        System.out.println("Inside Airplane()");
        fuselage = "Body";
        wings = "Airfoils";
        tail = "Empennage";
    }
    public String toString() {
        if(e == null) // lazy (delayed) initialization:
            e = new Engine();//构造器初始化  e这个引用指向 Engine 新的实例
        return "fuselage = " + fuselage + "\n " +
                "wings = " + wings + "\n" +
                "tail = " + tail + "\n " +
                "Engine = " + e;
    }
    public static void main(String[] args) {
        no1 N1234 = new no1();
        System.out.println(N1234);
    }
}