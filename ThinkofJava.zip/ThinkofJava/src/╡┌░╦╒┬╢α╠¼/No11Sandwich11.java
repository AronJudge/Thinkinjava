package 第八章多态;

class Meal {
    Meal() {
        System.out.println("Meal()"); }
}

class Bread {
    Bread() {
        System.out.println("Bread()"); }
}

class Cheese {
    Cheese() {
        System.out.println("Cheese()"); }
}

class Lettuce {
    Lettuce() {
        System.out.println("Lettuce()"); }
}

class Pickle {
    Pickle() {
        System.out.println("Pickle()"); }
}

class Lunch extends Meal {
    Lunch() {
        System.out.println("Lunch()"); }
}

class PortableLunch extends Lunch {
    PortableLunch() {
        System.out.println("PortableLunch()"); }
}

public class No11Sandwich11 extends PortableLunch {
    private Bread b = new Bread();
    private Cheese c = new Cheese();
    private Pickle p = new Pickle();
    private Lunch l = new Lunch();
    public No11Sandwich11() {
        System.out.println("Sandwich()"); }
    public static void main(String[] args) {
        new No11Sandwich11();
    }
}