package 第八章多态;

import java.util.Random;

class RandomRodentGenerator9 {
    private Random rand = new Random();
    public Rodent next() {
        switch(rand.nextInt(3)) {
            default:
            case 0: return new Mouse();
            case 1: return new Rat();
            case 2: return new Squirrel();
        }
    }
}

class Rodent {
    private String name = "Rodent";
    protected void eat() {
        System.out.println("Rodent.eat()"); }
    protected void run() {
        System.out.println("Rodent.run()"); }
    protected void sleep() {
        System.out.println("Rodent.sleep()"); }
    public String toString() { return name; }
}

class Mouse extends Rodent {
    private String name = "Mouse";
    protected void eat() {
        System.out.println("Mouse.eat()"); }
    protected void run() {
        System.out.println("Mouse.run()"); }
    protected void sleep() {
        System.out.println("Mouse.sleep()"); }
    public String toString() { return name; }
}

class Rat extends Rodent {
    private String name = "Rat";
    protected void eat() {
        System.out.println("Rat.eat()"); }
    protected void run() {
        System.out.println("Rat.run()"); }
    protected void sleep() {
        System.out.println("Rat.sleep()"); }
    public String toString() { return name; }
}

class Squirrel extends Rodent {
    private String name = "Squirrel";
    protected void eat() {
        System.out.println("Squirrel.eat()"); }
    protected void run() {
        System.out.println("Squirrel.run()"); }
    protected void sleep() {
        System.out.println("Squirrel.sleep()"); }
    public String toString() { return name; }
}

public class No9Rodent {
    private static RandomRodentGenerator9 gen = new RandomRodentGenerator9();
    public static void main(String[] args) {
        Rodent[] rodents = new Rodent[5];
        for(Rodent r : rodents) {
            r = gen.next();
            System.out.println(r + ": ");
            r.eat();
            r.run();
            r.sleep();
        }
    }
}