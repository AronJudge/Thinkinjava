package 第八章多态;

class Cycle1 {
    private String name = "Cycle";
    public static void travel(Cycle1 c) {
        System.out.println("Cycle.ride() " + c);
    }
    public String toString() {
        return this.name;
    }
}

class Unicycle1 extends Cycle1 {
    private String name = "Unicycle";
    public String toString() {
        return this.name;
    }
}

class Bicycle1 extends Cycle1 {
    private String name = "Bicycle";
    public String toString() {
        return this.name;
    }

}

class Tricycle1 extends Cycle1 {
    private String name = "Tricycle";
    public String toString() {
        return this.name;
    }
}

public class No1biking {
    public static void ride(Cycle1 c) {
        c.travel(c);
    }
    public static void main(String[] args) {
        Unicycle1 u = new Unicycle1();
        Bicycle1 b = new Bicycle1();
        Tricycle1 t = new Tricycle1();
        ride(u);
        ride(b);
        ride(t);
    }
}