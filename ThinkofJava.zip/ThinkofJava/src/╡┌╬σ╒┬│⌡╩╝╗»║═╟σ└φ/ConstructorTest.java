package 第五章初始化和清理;

class Tester2{
    String s1;
    String s2 = "hello";
    String s3 = "initnization by self";
    Tester2(){
        s3 = "constructor initnizetion";
    }
}
public class ConstructorTest {
    public static void main(String[] args) {
        Tester2 t2 = new Tester2();
        System.out.println("t2.s1="+ t2.s1);
        System.out.println("t2.s2="+ t2.s2);
        System.out.println("t2.s3="+ t2.s3);
    }
}
