package 第五章初始化和清理;

class WebBank{
    boolean loggedIn = false;
    WebBank(boolean logStatus){
        loggedIn = logStatus;
    }
    void logIn(){
        loggedIn = true;
    }
    void logOut(){
        loggedIn = false;
    }
    protected void finalize(){
        if (loggedIn)
            System.out.println("Error : still logged in");
    }
}
public class TerminationConditionEx {
    public static void main(String[] args) {
        WebBank bank1 = new WebBank(true);
        WebBank bank2 = new WebBank(true);  // 定义出来不用 垃圾回收自动清理
        bank1.logOut();
        new WebBank(true);  //  一直new 一个 对象 ，一直得不到清理。调用 fianlize方法 检查 验证终结条件
        System.gc();

    }
}
