package 第五章初始化和清理;

class Test {
    String s;
    {
        s = "Initializing string in Tester";
        System.out.println(s);
    }
    Test() {
        System.out.println("Tester()");
    }
}

public class InstanceClauseTest {
    public static void main(String[] args) {
        new Test();
    }
}
