package 第五章初始化和清理;


public class DefaultConstructorTest2 {

}
