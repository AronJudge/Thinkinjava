package 第五章初始化和清理;

public class Doc {
    public static void main(String[] args) {
        new Doc1().intubate();
    }
}
class Doc1{
    void intubate() {
        System.out.println("prepare patient");
        laryngoscopy();
        this.laryngoscopy();
    }
    void laryngoscopy() {
        System.out.println("use laryngoscope");
    }

}