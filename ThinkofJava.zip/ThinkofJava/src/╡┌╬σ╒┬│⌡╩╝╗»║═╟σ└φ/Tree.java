package 第五章初始化和清理;

class Tester {
        String s;
        }

public class Tree {
    public static void main(String[] args) {
        Tester t = new Tester();
        System.out.println(t.s);
    }
}