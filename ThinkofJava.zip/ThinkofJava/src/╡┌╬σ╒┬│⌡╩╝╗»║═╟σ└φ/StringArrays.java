package 第五章初始化和清理;

public class StringArrays {

        public static void main(String[] args) {
            String[] s = { "one", "two", "three", };
            for(int i = 0; i < s.length; i++)
                System.out.println("s[" + i + "] = " + s[i]);
        }
    }
