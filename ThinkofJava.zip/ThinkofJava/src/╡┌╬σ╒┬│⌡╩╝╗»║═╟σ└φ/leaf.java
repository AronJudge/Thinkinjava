package 第五章初始化和清理;

public class leaf {
    int i =0;
    leaf increment(){
        i++;
        return this;
    }
    void print(){
        System.out.println("i = " +i);
    }

    public static void main(String[] args) {
        leaf x = new leaf();
        x.increment().increment().increment().print();
    }
}
