package 第五章初始化和清理;

class Kabayo{
    Kabayo(){
        System.out.println(" is a Constructor");
    }
}

public class DefaultConstructorTest {
    public static void main(String[] args) {
        Kabayo k = new Kabayo();
    }
}
