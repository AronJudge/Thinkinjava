package 第五章初始化和清理;


class InitTest1 {
    InitTest1(String s) {
        System.out.println("InitTest1()");
        System.out.println(s);
    }
}

public class InitText {
    public static void main(String[] args) {
        InitTest1[] it = new InitTest1[10];
    }
}