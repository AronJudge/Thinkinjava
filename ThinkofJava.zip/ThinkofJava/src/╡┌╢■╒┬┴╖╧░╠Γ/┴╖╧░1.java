package 第二章练习题;

public class 练习1 {
    static int i;
    static char c;

    public static void main(String[] args) {
        System.out.println("int = " +i);
        System.out.println("char = " + c);
    }
}
