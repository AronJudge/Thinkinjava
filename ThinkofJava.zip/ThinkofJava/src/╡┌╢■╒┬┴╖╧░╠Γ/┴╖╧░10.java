package 第二章练习题;

public class 练习10 {
    public static void main(String[] args) {
        System.out.println("args[0] = " + args[0]);
        System.out.println("args[1] = " + args[1]);
        System.out.println("args[2] = " + args[2]);
    }
}
