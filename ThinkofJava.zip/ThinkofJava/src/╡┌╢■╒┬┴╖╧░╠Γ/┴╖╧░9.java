package 第二章练习题;


public class 练习9 {
    public static void main(String[] args) {
        boolean a = false;
        Boolean A = a;
        System.out.println(a);
        System.out.println(A);
        int b = 1;
        Integer B = b;
        System.out.println(b);
        System.out.println(B);
    }
}
