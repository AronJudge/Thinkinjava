package 第二章练习题;

public class 练习12 {
    /**
     * @param args array of string arguments
     * @author LMW
     * @version jdk9.0
     */
    public static void main(String[] args) {
        System.out.println("Doc文档");

    }

}
