package 第十四章类型信息;
import java.util.*;

public class Shapes4 {
    public static void main(String[] args) {
        // upcasting to Shape:
        List<Shape> shapeList = Arrays.asList(
                new Circle(), new Square(), new Triangle(), new Rhomboid()
        );
        // downcasting back to specific shape:
        for(Shape shape : shapeList)
            shape.draw();
        Rhomboid r = new Rhomboid();
        // Upcast:
        Shape s = (Shape)r;
        s.draw();
        // check type before downcast:
        if(s instanceof Circle)
            ((Circle)s).draw();
        else if(!(s instanceof Circle))
            System.out.println("(Shape)r is not a Circle");
    }
}