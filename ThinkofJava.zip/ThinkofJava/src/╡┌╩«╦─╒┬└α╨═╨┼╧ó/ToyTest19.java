package 第十四章类型信息;

// In ToyTest.java, use reflection to create a Toy object using
// the non-default constructor.

import java.lang.reflect.*;

class Toy19 {
    Toy19() {
        System.out.println("Creating Toy() object");
    }
    Toy19(int i) {
        System.out.println("Creating Toy(" + i + ") object");
    }
}


public class ToyTest19 {
    public static void main(String[] args) {
        // get appropriate constructor and create new instance:
        try {
            Toy19.class.getDeclaredConstructor(int.class).newInstance(1);
            // catch four exceptions:
        } catch(NoSuchMethodException e) {
            System.out.println("No such method: " + e);
        } catch(InstantiationException e) {
            System.out.println("Unable make Toy: " + e);
        } catch(IllegalAccessException e) {
            System.out.println("Unable access: " + e);
        } catch(InvocationTargetException e) {
            System.out.println("Target invocation problem: " + e);
        }
    }
}