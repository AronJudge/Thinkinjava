package 第四章流程控制;

public class 练习8 {
    public static void main(String[] args) {
        for(int i = 0; i < 11; i++) {
            switch(i) {
                case 0:
                    System.out.println("zero");
                case 1:
                    System.out.println("isa");
                case 2:
                    System.out.println("dalawa"); break;
                case 3:
                    System.out.println("tatlo"); break;
                case 4:
                    System.out.println("apat"); break;
                case 5:
                    System.out.println("lima"); break;
                case 6:
                    System.out.println("anim"); break;
                case 7:
                    System.out.println("pito"); break;
                case 8:
                    System.out.println("walo"); break;
                case 9:
                    System.out.println("siyam"); break;
                default:
                    System.out.println("default");
            }
        }
    }
}
