package 算法;

public class DecTBinary {
    DecTBinary(int nData, int nByte) {
        int i = 0, j = 0;
        int nArr[] = new int[16];//自动初始化
        while (nData != 0) {
            i = nData % 2;
            nArr[j++] = i;
            nData = nData / 2;
        }
        j = nByte - 1;
        for (; j >= 0; j--) {
            System.out.print(nArr[j]);
        }
        System.out.println(" ");
    }

    public static void main(String[] args) {

        double n = Math.pow(2.0,5);
        System.out.println(n);


        for (int i = 0;i < n;i ++)
        {
           DecTBinary dec = new DecTBinary(i,5);

        }
    }
}
