package 第十五章泛型;

// TIJ4 Chapter Generics, Exercise 3, page 624
// Create and test a SixTuple generic.

class Robot1 {}
class Amphibian {}
class Vehicle {}

class SixTuple<A,B,C,D,E,F> {
    public final A first;
    public final B second;
    public final C third;
    public final D fourth;
    public final E fifth;
    public final F sixth;
    public SixTuple(A a, B  b, C c, D d, E e, F f) {
        first = a;
        second =b;
        third = c;
        fourth = d;
        fifth = e;
        sixth = f;
    }
    public String toString() {
        return "(" + first + ", " + second + ", " +
                third + ", " + fourth + ", " + fifth + ", " + sixth +")";
    }
}

public class SixTupleTest {
    static SixTuple<Robot1, Vehicle, Amphibian, String, Integer, Double> f() {
        return new SixTuple<Robot1, Vehicle, Amphibian, String, Integer, Double>(
                new Robot1(), new Vehicle(), new Amphibian(), "hi", 470, 11.1);
    }
    public static void main(String[] args) {
        SixTuple<Robot1, Vehicle, Amphibian, String, Integer, Double> st = f();
        System.out.println(st);
        System.out.println(f());
    }
}