package 第九章接口;

class StringMixer {
	static String process(String s) {
		char[] ca = new char[s.length()];
		if((s.length())%2 == 0) {
			for(int i = 0; i < s.length(); i += 2) {
				ca[i] = s.charAt(i + 1);//charAt() 方法用于返回指定索引处的字符。索引范围为从 0 到 length() - 1
				ca[i + 1] = s.charAt(i);
			}
			return new String(ca);
		}
		else {
		for(int i = 0; i < s.length() - 1; i += 2) {
				ca[i] = s.charAt(i + 1);
				ca[i + 1] = s.charAt(i);
			}
			ca[s.length() - 1] = s.charAt(s.length() - 1);
			return new String(ca);
		}
	}
 }

// program takes command line String argument:

// 配置适配器
class StringMixerAdapter implements Processor {
    public String name() { return "StringMixerAdapter"; }
    StringMixer stringMixer;//空引用
    public StringMixerAdapter(StringMixer stringMixer) {//传入 StringMixer 实例化对象
        this.stringMixer = stringMixer;//把这个空引用 指向当前对象的stringMixer 的实例化
    }
    public String process(Object input) {
        return stringMixer.process((String)input);//在 Apply 里面被调用
    }
}


public class No10StringMixerProcessor  {
    public static void main(String[] args) {
        String s = "asdkfs";
        Apply.process(new StringMixerAdapter(new StringMixer()), s);//给StringMixerAdapter的构造器传入StringMixer的实例化对象；
    }
}
