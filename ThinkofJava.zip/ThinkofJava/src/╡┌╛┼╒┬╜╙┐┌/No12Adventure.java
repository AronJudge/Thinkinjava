package 第九章接口;

interface CanFight {
    void fight();
}

interface CanSwim {
    void swim();
}

interface CanFly {
    void fly();
}

interface CanClimb {
    void climb();
}

class ActionCharacter {
    public void fight() {}
}

class Hero extends ActionCharacter
        implements CanFight, CanSwim, CanFly,CanClimb{
    public void swim() {}
    public void fly() {}
    public void climb(){}
}

public class No12Adventure {
    public static void t(CanFight x) {
        x.fight();
        System.out.println("fight");
    }
    public static void u(CanSwim x) {
        x.swim();
        System.out.println("Swim");
    }
    public static void v(CanFly x) {
        x.fly();
        System.out.println("Fly");
    }
    public static void c(CanClimb x) {
        x.climb();
        System.out.println("Climb");
    }
    public static void w(ActionCharacter x) {
        x.fight();
        System.out.println("fight");
    }
    public static void main(String[] args) {
        Hero h = new Hero();
        t(h); // Treat it as a CanFight
        u(h); // Treat it as a CanSwim
        v(h); // Treat it as a CanFly
        c(h); // Treat it as a CanClimb
        w(h); // Treat it as an ActionCharacter
    }
}