package 第九章接口;


import java.util.Random;

interface Games {
    void play();
}

interface GamesFactory {
    Games getGames();//得到痕迹Game创建的实例对象
}

class CoinToss implements Games {
    Random rand = new Random();
    public void play() {
        System.out.print("Toss Coin: ");
        switch(rand.nextInt(2)) {
            case 0 :
                System.out.println("Heads"); return;
            case 1 :
                System.out.println("Tails"); return;
            default:
                System.out.println("OnEdge"); return;
        }
    }
}

class CoinTossFactory implements GamesFactory {
    public Games getGames() {
        return new CoinToss();  // 返回 它的实例化对象
    }
}

class DiceThrow implements Games {
    Random rand = new Random();
    public void play() {
        System.out.print("Throw Dice: " + (rand.nextInt(6) + 1));
    }
}

class DiceThrowFactory implements GamesFactory {
    public Games getGames() {
        return new DiceThrow();
    }
}


public class No19 {
    public static void playGame(GamesFactory factory) {
        Games g = factory.getGames();
        g.play();
    }
    public static void main(String [] args) {
        playGame(new CoinTossFactory());
        playGame(new DiceThrowFactory());
    }
}