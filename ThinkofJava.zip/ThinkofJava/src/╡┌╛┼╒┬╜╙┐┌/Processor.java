package 第九章接口;

public interface Processor {
    String name();
    Object process(Object input);
}
class Apply{
    public static void process(Processor p,Object s){
        System.out.println("Using StringMixerAdapter"+p.name());
        System.out.println(p.process(s));
    }
}
