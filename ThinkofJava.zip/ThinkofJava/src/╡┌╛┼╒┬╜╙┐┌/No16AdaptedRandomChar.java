package 第九章接口;

import java.nio.CharBuffer;
import java.util.Scanner;

public class No16AdaptedRandomChar extends No14RandomChar implements Readable {
    private int count;
    public No16AdaptedRandomChar(int count) {
        this.count = count;
    }
    public int read(CharBuffer cb) {//Readable 只要实现一个read 方法
        if(count-- == 0) return -1;
        String result = Character.toString(next()) + " ";
        cb.append(result);
        System.out.print("result"+result);
        return result.length();
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(new No16AdaptedRandomChar(10));
        while(s.hasNext())
            System.out.println(s.next() + " ");
    }
}
