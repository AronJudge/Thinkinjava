package 第九章接口;

import java.util.Random;

public class No14RandomChar {
    private static Random rand = new Random();
    public char next() {
        return (char) rand.nextInt(128);
    }
}